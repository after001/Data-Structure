/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aed1_ziviani;

import guia03.Agenda1;
import java.io.IOException;



/**
 *
 * @author Thiago
 */
public class Aed1_ziviani {
    
    public static void main(String[] args) throws IOException {
        Agenda1.read();
    }
    
  
}
