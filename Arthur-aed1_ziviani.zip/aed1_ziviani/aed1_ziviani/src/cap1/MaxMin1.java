/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cap1;

import utils.Complexity;

/**
 *
 * @author Thiago
 */
public class MaxMin1{
    
    public static int[] maxMin1(int v[], int n) {
        Complexity complexity = new Complexity();
        
        int max = v[0], min = v[0];
        for (int i = 1; i < n; i++) {
            
            complexity.incr();
            if (v[i] > max){                
                max = v[i];                
            }
                
            complexity.incr();
            if (v[i] < min){                
                min = v[i];                
            }
                
        }
        int maxMin[] = new int[3];
        maxMin[0] = max;
        maxMin[1] = min;
        maxMin[2] = complexity.getCount();
        return maxMin;
    }
}
