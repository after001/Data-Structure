/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cap1;

import utils.Complexity;

/**
 *
 * @author Thiago
 */
public class MaxMin3{    
    
    public static int[] maxMin3(int v[], int n) {
        Complexity complexity = new Complexity();
        
        int max, min, FimDoAnel;
        if ((n % 2) > 0) {
            v[n] = v[n - 1];
            FimDoAnel = n;
        } else
            FimDoAnel = n - 1;
        if (v[0] > v[1]) {
            max = v[0];
            min = v[1];
        } else {
            max = v[1];
            min = v[0];
        }
        int i = 2;
        while (i < FimDoAnel) {
            complexity.incr();
            if (v[i] > v[i + 1]) {  
                complexity.incr();
                if (v[i] > max){                    
                    max = v[i];                    
                }
                
                complexity.incr();
                if (v[i + 1] < min){                    
                    min = v[i + 1];                    
                }     
            } else {
                complexity.incr();
                if (v[i] < min){                    
                    min = v[i];
                }
                
                complexity.incr();
                if (v[i + 1] > max){                    
                    max = v[i + 1];
                }
                    
            }
            i = i + 2;
        }
        int maxMin[] = new int[3];
        maxMin[0] = max;
        maxMin[1] = min;
        maxMin[2] = complexity.getCount();
        return maxMin;
    }
}
