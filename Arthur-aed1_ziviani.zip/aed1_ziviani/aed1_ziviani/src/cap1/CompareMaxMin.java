/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cap1;

import utils.Array;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Thiago
 */
public class CompareMaxMin {
    CompareMaxMin(){
        final int SIZE = 100;
        
        //Melhor caso
        int[] vMelhorCaso = Array.initAscending(SIZE);
        
        int[] maxMin1_MC = MaxMin1.maxMin1(vMelhorCaso, SIZE);
        int[] maxMin2_MC = MaxMin2.maxMin2(vMelhorCaso, SIZE);
        int[] maxMin3_MC = MaxMin3.maxMin3(vMelhorCaso, SIZE);
                
        System.out.println("Melhor caso");
        Array.print(maxMin1_MC);     
        Array.print(maxMin2_MC);  
        Array.print(maxMin3_MC);          
        
        //Caso médio
        int[] vCasoMedio = Array.initRandomWithoutDiplicates(SIZE);
        
        int[] maxMin1_CM = MaxMin1.maxMin1(vCasoMedio, SIZE);
        int[] maxMin2_CM = MaxMin2.maxMin2(vCasoMedio, SIZE);
        int[] maxMin3_CM = MaxMin3.maxMin3(vCasoMedio, SIZE);
                
        System.out.println("Caso médio");
        Array.print(maxMin1_CM);     
        Array.print(maxMin2_CM);  
        Array.print(maxMin3_CM);  
        
        //Pior caso
        int[] vPiorCaso = Array.initDescending(SIZE);
        
        int[] maxMin1_PC = MaxMin1.maxMin1(vPiorCaso, SIZE);
        int[] maxMin2_PC = MaxMin2.maxMin2(vPiorCaso, SIZE);
        int[] maxMin3_PC = MaxMin3.maxMin3(vPiorCaso, SIZE);
                
        System.out.println("Pior caso");
        Array.print(maxMin1_PC);     
        Array.print(maxMin2_PC);  
        Array.print(maxMin3_PC);   
    }
}
