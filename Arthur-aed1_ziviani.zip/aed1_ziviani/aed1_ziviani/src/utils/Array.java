/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utils;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Thiago
 */
public class Array {
    /**
     * Imprime um array
     */
    public static void print(int[] v){
        for (int i = 0; i < v.length; i++){
            System.out.print(v[i] + "\t");
            if((i+1) % 10 == 0){
                System.out.print("\n");
            }
        }
            
        System.out.print("\n");
    }
    
    /**
     * Inicializa um array de inteiros de tamanho n, com valores de 0 a n-1.
     * Os valores podem repetir.
     */
    public static int[] initRandom(int n){
        int[] v = new Random().ints(n, 0, n).toArray();
        return v;
    }
    
    /**
     * Inicializa aleatoriamente um array de inteiros de tamanho n, com valores de 0 a n-1.
     * Os valores NÃO repetem.
     */    
    public static int[] initRandomWithoutDiplicates(int n){
        //Declara um array de tamanho n
        int[] v = new int[n];
        
        //Cria o TAD ArrayList temporária para armazenar os valores em ordem crescente
        ArrayList<Integer> list = new ArrayList<Integer>(n);
        for(int i = 0; i < n; i++) {
            list.add(i);
        }

        //Escolhe aleatoriamente um item/posição da TAD para ser incluído do array v
        //O valor do item/posição escolhido é adicionado ao array e excluído do ArrayList
        Random rand = new Random();
        int pos = 0;
        while(list.size() > 0) {
            int index = rand.nextInt(list.size());
            v[pos] = list.remove(index);
            pos++;
        }
        
        return v;
    }
    
    /**
     * Inicializa um array de inteiros de tamanho n, com valores de 0 a n-1.
     */ 
    public static int[] initAscending(int n){
        int[] v = new int[n];
        for(int i = 0; i < n; i++) {
            v[i] = i;
        }
        return v;
    }
    
    /**
     * Inicializa um array de inteiros de tamanho n, com valores de n-1 a 0.
     */ 
    public static int[] initDescending(int n){
        int[] v = new int[n];
        for(int i = 0; i < n; i++) {
            v[i] = n - i - 1;
        }
        return v;
    }  
}
