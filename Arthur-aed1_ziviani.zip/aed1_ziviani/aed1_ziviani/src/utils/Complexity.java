/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utils;

/**
 *
 * @author Thiago
 */
public class Complexity {
    private int count;
    
    public Complexity(){
        restart();
    }
    
    public void restart(){
        count = 0;
    }
    
    public void incr(){
        count++;
    }

    public int getCount() {
        return count;
    }
    
    public void printCount(){
        System.out.println("Count: "+count);
    }
    
}
