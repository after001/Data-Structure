/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guia03;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author Thiago
 */
public class Agenda1 {
    public static void read() throws FileNotFoundException, IOException {
        List<List<String>> records = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(
                new FileReader("C:/Users/arthu/Downloads/aed1_ziviani/aed1_ziviani/src/guia03/agenda.csv"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                records.add(Arrays.asList(values));
            }
        }

        // System.out.println(records.get(0).get(0));
        // System.out.println(records.get(0).get(1));
        // System.out.println(records);

        search(records, "Amor");
    }

    public static void search(List<List<String>> lista, String nome) {
        try {

            int listaLength = lista.size();

            int middleOfList = listaLength / 2;

            int order = nome.compareTo(lista.get(middleOfList).get(0));
            int compare = 0;

            while (order != 0) {

                if (order > 0) {
                    
                } else if (order < 0) {
                    middleOfList = middleOfList / 2;
                    int newOrder = lista.get(middleOfList).get(0).compareTo(nome);

                    order = newOrder;
                    compare++;
                }

            }
            System.out.println("Nome do objeto : " + lista.get(middleOfList).get(0) + "\nTelefone : "
                    + lista.get(middleOfList).get(1) + "\nComparações feitas : " + compare);

        } catch (Exception e) {
            // TODO: handle exception
        }

    }

}
